const express = require("express");
const router  = express.Router();
const verifyToken = require("../middlewares/auth.middleware");
const { getBookingViolations } = require("../controllers/violations/violations.controller");

router.get("/booking/:bookingID", verifyToken, getBookingViolations);

module.exports = router;