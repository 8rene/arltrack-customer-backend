// bookingSessions/{bookingID} — doc ID IS the bookingID (1:1 with a booking,
// so lookups are a direct .doc(bookingID).get(), never a query).
//
// NOTE: geofence radius below is a placeholder (500m) — the real fixed
// radius value hasn't been decided yet. Change GEOFENCE_RADIUS_METERS
// once that's picked.
const GEOFENCE_RADIUS_METERS = 500;

const createBookingSession = (bookingID, data = {}) => ({
  bookingID,
  pickupLocation:  data.pickupLocation  || null, // { address, lat, lng } — raw pin, not a geofence zone
  dropoffLocation: data.dropoffLocation || null, // { address, lat, lng }
  geofenceZones:   Array.isArray(data.geofenceZones) ? data.geofenceZones : [],
  geofenceAlerts:  [],
  codingAlerts:    [],
  // Audit trail from the coding-rule check at booking time — see
  // bookings.controller.js for how this gets populated.
  codingCheck:     data.codingCheck || null,
  pickupTime:      data.pickupTime || null,
  returnTime:      data.returnTime || null,
  currentPosition: null, // { lat, lng, date } — set on first ping, edge-checked after
  createdAt:       new Date(),
  updatedAt:       new Date(),
});

// Helper: build a geofence_zones entry from a raw {lat,lng} point.
// Returns null if the point is missing coords (caller should skip it).
const makeZone = (label, point) => {
  if (!point || typeof point.lat !== "number" || typeof point.lng !== "number") return null;
  return {
    label,
    lat:    point.lat,
    lng:    point.lng,
    radius: GEOFENCE_RADIUS_METERS,
  };
};

module.exports = createBookingSession;
module.exports.makeZone = makeZone;
module.exports.GEOFENCE_RADIUS_METERS = GEOFENCE_RADIUS_METERS;