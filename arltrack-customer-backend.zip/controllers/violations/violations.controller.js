// Customer side of the traffic-violation log.
//   GET /api/violations/booking/:bookingID   the notices our team has recorded for one of THEIR bookings
// Staff record notices that reach the company (and move them to paid/billed/recovered) in the
// admin app, on the same `violations` collection — see utils/violations/violations.util.js.
// (Renters can no longer report a ticket themselves; older customer-reported notices still show here.)
const { db } = require("../../config/firebaseConnection/firebase");
const { loadOwnedBooking, toISO } = require("../../utils/bookings/ownedBooking.util");
const { VIOLATION_STATUS } = require("../../utils/violations/violations.util");

// What the customer is allowed to see of a violation doc.
const customerView = (id, d) => ({
  violationID:   id,
  type:          d.type || "Other",
  occurredAt:    toISO(d.occurredAt),
  location:      d.location || "",
  noticeNumber:  d.noticeNumber || "",
  amount:        d.amount ?? null,
  status:        d.status || VIOLATION_STATUS.REPORTED,
  source:        d.source === "customer" ? "customer" : "staff",
  withinRental:  d.withinRental ?? null,
  contestDeadline: toISO(d.contestDeadline),
  createdAt:     toISO(d.createdAt),
});

const getBookingViolations = async (req, res) => {
  try {
    const booking = await loadOwnedBooking(req.user?.userID, req.params.bookingID);
    if (!booking) return res.status(404).json({ message: "Booking not found." });
    const snap = await db.collection("violations").where("bookingID", "==", booking.bookingID).get();
    const violations = snap.docs
      .map((d) => customerView(d.id, d.data()))
      .sort((a, b) => String(b.createdAt || "").localeCompare(String(a.createdAt || "")));
    return res.json({ violations });
  } catch (error) {
    console.error("getBookingViolations error:", error);
    return res.status(500).json({ message: "Could not load the notices for this booking." });
  }
};

module.exports = { getBookingViolations };