const { db, auth } = require("../../config/firebaseConnection/firebase");
const { isBlockedAdminRole } = require("../../utils/roles/role.util");
const { verifyAndConsumeOTP, normalizeEmail } = require("./otp.controller");
const { ARCHIVED_MESSAGE, isArchivedUid } = require("../../utils/accountStatus/accountStatus.util");

// Same strength rule enforced client-side at signup (SignUpModal.jsx) —
// checked again here since this is a new, separate entry point.
const PASSWORD_REGEX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()\-_=+[\]{};':"\\|,.<>/?]).{8,64}$/;

// POST /api/auth/reset-password
// body: { email, otp, newPassword }
// Reuses the same 'otpCodes' collection/flow as signup's send-otp — the
// OTP must have already been requested via POST /api/auth/send-otp.
const resetPassword = async (req, res) => {
  const { otp, newPassword } = req.body;
  const email = normalizeEmail(req.body.email); // trimmed + lowercase, same key as send-otp

  if (!email || !otp || !newPassword || typeof email !== "string") {
    return res.status(400).json({ message: "Email, OTP, and new password are required." });
  }
  if (!PASSWORD_REGEX.test(newPassword)) {
    return res.status(400).json({
      message: "Password must be 8–64 characters with at least 1 uppercase, 1 lowercase, 1 number, and 1 special character.",
    });
  }

  try {
    // 1. Validate the OTP — same checks as verifyOTP in otp.controller.js
    const otpRef = db.collection("otpCodes").doc(email);

    // Only a code requested with purpose "reset" can reset a password — a
    // signup/login code for the same email must not. The check and the
    // wrong-guess count are one atomic step (verifyAndConsumeOTP in otp.controller.js); the code
    // is kept (consume: false) until the password has actually been changed.
    const result = await verifyAndConsumeOTP({ email, otp: String(otp), purpose: "reset", consume: false });

    if (result.status === "not_found") {
      return res.status(404).json({ message: "OTP not found. Please request a new one." });
    }
    if (result.status === "expired") {
      return res.status(400).json({ message: "OTP has expired. Please request a new one." });
    }
    if (result.status === "locked") {
      return res.status(429).json({ message: "Too many failed attempts. Please request a new OTP." });
    }
    if (result.status === "invalid") {
      return res.status(400).json({
        message: `Invalid OTP. ${result.remaining} attempt${result.remaining === 1 ? "" : "s"} remaining.`,
      });
    }

    // 2. OTP correct — find the Firebase Auth user for this email
    let firebaseUser;
    try {
      firebaseUser = await auth.getUserByEmail(email);
    } catch (err) {
      if (err.code === "auth/user-not-found") {
        return res.status(404).json({ message: "No account found with this email." });
      }
      throw err;
    }

    // 2a. Block admin-side accounts (Owner/Admin/Supervisor) from resetting
    // their password through the customer-facing site — mirrors the same
    // block in login.controller.js. This is checked again here (not just
    // at send-otp) since `purpose` on send-otp is client-supplied and
    // shouldn't be the only thing standing between a blocked role and a
    // password reset. Generic message, same reasoning as login.
    const userDoc = await db.collection("user").doc(firebaseUser.uid).get();
    // No profile doc = an account an admin deleted (archived): its login is only disabled, so it still resolves above.
    // Stop here: resetting the password would be pointless, and step 3a below would write a stray user doc for it.
    if (!userDoc.exists) {
      await otpRef.delete();
      if (await isArchivedUid(firebaseUser.uid)) {
        return res.status(403).json({ message: ARCHIVED_MESSAGE, archived: true });
      }
      return res.status(404).json({ message: "No account found with this email." });
    }
    const roleID  = userDoc.data().roleID;
    if (roleID && await isBlockedAdminRole(roleID, db)) {
      await otpRef.delete();
      return res.status(404).json({ message: "No account found with this email." });
    }

    // 3. Update the password
    await auth.updateUser(firebaseUser.uid, { password: newPassword });

    // 3a. End every session that already exists for this account — if someone else had a token
    // (that is often WHY the owner is resetting), it must stop working now. See verifyToken.
    // If this write fails the request errors out before the OTP is deleted, so the customer
    // can simply retry the reset with the same code.
    await db.collection("user").doc(firebaseUser.uid).set(
      { tokensValidAfter: Math.floor(Date.now() / 1000) },
      { merge: true }
    );

    // 4. OTP is single-use — delete it now that it's been consumed
    await otpRef.delete();

    return res.status(200).json({ message: "Password reset successfully. You can now log in with your new password." });

  } catch (err) {
    console.error("resetPassword error:", err);
    return res.status(500).json({ message: "Server error resetting password. Please try again." });
  }
};

module.exports = { resetPassword };