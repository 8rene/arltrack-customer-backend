const axios = require("axios");
const { db }  = require("../../config/firebaseConnection/firebase");
const jwt     = require("jsonwebtoken");
const { createSessionLog, expireStaleSessionsForUser } = require("../../utils/sessionLogs/sessionLogs.util");
const { checkAccountStatus } = require("../../utils/accountStatus/accountStatus.util");

// Admin-side role NAMES (from the shared 'roles' Firestore collection) —
// these accounts manage the fleet/bookings and should never be able to log
// into the customer-facing site. Driver is intentionally NOT blocked here
// since drivers may also need customer-side access depending on how the
// business uses that role; only Owner/Admin/Supervisor are blocked.
//
// NOTE: this checks the role doc's "name" field (confirmed in Firestore),
// NOT "roleName" — that mismatch was the root cause of the earlier bypass.
const BLOCKED_ADMIN_ROLE_NAMES = new Set(["Owner", "Admin", "Supervisor"]);


const isBlockedAdminRole = async (roleID) => {
  try {
    const roleSnap = await db.collection("roles").doc(roleID).get();

    if (!roleSnap.exists) {
      console.error(`Role lookup failed: no roles doc for roleID "${roleID}". Failing closed (blocking login).`);
      return true;
    }

    const roleName = roleSnap.data().name;
    return BLOCKED_ADMIN_ROLE_NAMES.has(roleName);
  } catch (err) {
    console.error(`Role lookup error for roleID "${roleID}":`, err.message, "— failing closed (blocking login).");
    return true;
  }
};

const login = async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: "Email and password are required." });
  }

  const firebaseApiKey = process.env.FIREBASE_API_KEY;

  if (!firebaseApiKey || firebaseApiKey === "your_firebase_web_api_key_here") {
    return res.status(500).json({ message: "Server misconfiguration: FIREBASE_API_KEY not set." });
  }

  try {
    // 1. Verify credentials via Firebase Auth REST API using axios
    const signInRes = await axios.post(
      `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${firebaseApiKey}`,
      { email, password, returnSecureToken: true },
      { headers: { "Content-Type": "application/json" } }
    );

    const uid = signInRes.data.localId;

    // 2. Fetch user document from Firestore
    const userDoc = await db.collection("user").doc(uid).get();

    if (!userDoc.exists) {
      return res.status(404).json({ message: "User record not found." });
    }

    const userData = userDoc.data();

    // 2a. Check if account is pending admin approval, or has been
    // deactivated by an admin. Single source of truth in
    // accountStatus.util.js — shared with google.controller.js — so this
    // can't silently drift out of sync between login paths again.
    const statusBlock = checkAccountStatus(userData, uid);
    if (statusBlock) {
      return res.status(statusBlock.httpStatus).json({ message: statusBlock.message });
    }

    // 2b. Block admin-side accounts (Owner/Admin/Supervisor) from logging
    // into the customer-facing site — they belong on the admin panel only.
    // Message is intentionally generic ("does not exist") rather than
    // confirming this is an admin account, so login attempts here don't
    // leak which emails belong to staff accounts.
    if (userData.roleID && await isBlockedAdminRole(userData.roleID)) {
      return res.status(404).json({
        message: "The user does not exist.",
      });
    }

    // 3. Issue JWT
    const token = jwt.sign(
      {
        userID:   uid,
        email:    userData.email,
        roleID:   userData.roleID,
        username: userData.username || "",
      },
      process.env.JWT_SECRET,
      { expiresIn: "1d" }
    );

    // Close out any of this account's own sessions that never got an
    // explicit logout (tab closed before the token expired client-side) —
    // catches it right away instead of waiting for the nightly sweep.
    expireStaleSessionsForUser(uid);

    // Log this session for the admin's Session Logs page — fire without
    // blocking the response; a logging hiccup should never fail a login.
    createSessionLog(uid, userData.username || "");

    return res.status(200).json({
      message: "Login successful",
      token,
      user: {
        userID:       uid,
        email:        userData.email,
        phone:        userData.phone        || "",
        username:     userData.username     || "",
        roleID:       userData.roleID       || "",
        profileImage: userData.profileImage || "",
        isVerified:   userData.isVerified   || false,
      },
    });

  } catch (error) {
    // Axios wraps HTTP errors — check the Firebase error code
    const code = error.response?.data?.error?.message || "";
    console.error("Login error code:", code);

    if (
      code.includes("EMAIL_NOT_FOUND") ||
      code.includes("INVALID_PASSWORD") ||
      code.includes("INVALID_LOGIN_CREDENTIALS") ||
      code.includes("INVALID_EMAIL")
    ) {
      return res.status(401).json({ message: "Invalid email or password." });
    }
    if (code.includes("USER_DISABLED")) {
      return res.status(403).json({ message: "Your account has been disabled." });
    }
    if (code.includes("TOO_MANY_ATTEMPTS_TRY_LATER") || code.includes("TOO_MANY_ATTEMPTS")) {
      return res.status(429).json({ message: "Too many failed attempts. Please try again later." });
    }
    if (code.includes("API_KEY_INVALID") || code.includes("API key not valid")) {
      return res.status(500).json({ message: "Server misconfiguration: invalid Firebase API key." });
    }

    console.error("Login error:", error.message);
    return res.status(500).json({ message: "Server error. Please try again." });
  }
};

module.exports = { login };