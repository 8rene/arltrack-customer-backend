const crypto = require("crypto");
const { db } = require("../../config/firebaseConnection/firebase");

// An Inactive car (sold, retired, ...) must not appear anywhere on the customer side -- not in the showroom, the
// featured cars, the booking page or a direct link. (Maintenance cars are still listed here: the showroom shows them;
// only the Booking page hides them.) Status casing is not trusted: "Inactive" / "inactive" both count.
const isInactiveCar = (data) => String((data && data.status) || "").trim().toLowerCase() === "inactive";

// A flagged customer's reviews are not shown to anyone (car page, review counts, "most reviewed" ranking). Staff still see
// them in the admin Reviews page, marked Flagged. Returns the Set of userIDs (from the given list) whose account is flagged
// RIGHT NOW, read from the live user record, so un-flagging someone brings their reviews back on its own.
// If the lookup itself fails the reviews are left visible (and the error logged) rather than breaking the page.
const flaggedUserIDs = async (userIDs) => {
  const ids = [...new Set((userIDs || []).filter(Boolean).map(String))];
  const flagged = new Set();
  if (!ids.length) return flagged;
  try {
    for (let i = 0; i < ids.length; i += 300) {
      const refs = ids.slice(i, i + 300).map((id) => db.collection("user").doc(id));
      const snaps = await db.getAll(...refs);
      snaps.forEach((s) => { if (s.exists && s.data().isFlagged === true) flagged.add(s.id); });
    }
  } catch (err) {
    console.error("flaggedUserIDs error:", err.message);
  }
  return flagged;
};

// Helper: resolve car details (brand, model, primary image, all pricing)
const resolveCarDetails = async (carID, carData, brandMap, modelMap) => {
  const brand = brandMap[carData.brandID] || "";
  const model = modelMap[carData.modelID] || "";

  // Fetch primary image
  let imageURL = "";
  try {
    const imgSnap = await db
      .collection("carImages")
      .where("carID", "==", carID)
      .where("isPrimary", "==", true)
      .limit(1)
      .get();
    if (!imgSnap.empty) {
      imageURL = imgSnap.docs[0].data().imageURL || "";
    }
  } catch (_) {}

  // Fetch all pricing for this car
  let pricing = [];
  try {
    const priceSnap = await db
      .collection("carPricing")
      .where("carID", "==", carID)
      .get();
    if (!priceSnap.empty) {
      pricing = priceSnap.docs
        .map((d) => ({ durationType: d.data().durationType, price: d.data().price }))
        .sort((a, b) => a.price - b.price);
    }
  } catch (_) {}

  return {
    carID,
    name:             `${brand} ${model}`.trim(),
    brandName:        brand,
    modelName:        model,
    bodyType:         carData.bodyType         || "",
    color:            carData.color            || "",
    fuelType:         carData.fuelType         || "",
    transmission:     carData.transmission     || "",
    seatingCapacity:  carData.seatingCapacity  || 0,
    shortDescription: carData.shortDescription || "",
    longDescription:  carData.longDescription  || "",
    // plateNumber is deliberately NOT returned here — this endpoint is public (no login).
    year:             carData.year             || "",
    status:           carData.status           || "",
    imageURL,
    pricing,
    startingPrice:    pricing.length ? pricing[0].price        : null,
    durationType:     pricing.length ? pricing[0].durationType : null,
  };
};

// GET /api/cars/all — returns every car with full details
const getAllCars = async (req, res) => {
  try {
    const carsSnap = await db.collection("cars").get();

    if (carsSnap.empty) {
      return res.status(200).json([]);
    }

    // Collect all brandIDs and modelIDs
    const brandIDs = new Set();
    const modelIDs = new Set();
    const carsRaw  = [];

    carsSnap.docs.forEach((doc) => {
      const d = doc.data();
      if (isInactiveCar(d)) return;   // Inactive: not shown anywhere
      carsRaw.push({ id: doc.id, data: d });
      if (d.brandID) brandIDs.add(d.brandID);
      if (d.modelID) modelIDs.add(d.modelID);
    });

    // Batch-fetch brands and models
    const [brandDocs, modelDocs] = await Promise.all([
      Promise.all([...brandIDs].map((id) => db.collection("brand").doc(id).get())),
      Promise.all([...modelIDs].map((id) => db.collection("model").doc(id).get())),
    ]);

    const brandMap = {};
    brandDocs.forEach((d) => { if (d.exists) brandMap[d.id] = d.data().brandName || ""; });

    const modelMap = {};
    modelDocs.forEach((d) => { if (d.exists) modelMap[d.id] = d.data().modelName || ""; });

    // Resolve full details for every car in parallel
    const resolved = await Promise.all(
      carsRaw.map(({ id, data }) => resolveCarDetails(id, data, brandMap, modelMap))
    );

    return res.status(200).json(resolved);

  } catch (error) {
    console.error("getAllCars error:", error);
    return res.status(500).json({ message: "Failed to fetch cars." });
  }
};

// GET /api/cars/featured
const getFeaturedCars = async (req, res) => {
  try {
    // 1. Get all cars first to know valid carIDs (Firestore `in` needs explicit IDs)
    const carsSnap = await db.collection("cars").get();
    if (carsSnap.empty) {
      return res.status(200).json({ mostReviewed: [], mostBooked: [] });
    }

    const carDataMap = {};
    const brandIDs   = new Set();
    const modelIDs   = new Set();
    const allCarIDs  = [];

    carsSnap.docs.forEach((doc) => {
      if (isInactiveCar(doc.data())) return;   // Inactive: never featured
      carDataMap[doc.id] = doc.data();
      allCarIDs.push(doc.id);
      if (doc.data().brandID) brandIDs.add(doc.data().brandID);
      if (doc.data().modelID) modelIDs.add(doc.data().modelID);
    });

    // 2. Query only reviews and bookings for known cars (max 30 per `in` query — safe for a car fleet)
    const carIDChunks = [];
    for (let i = 0; i < allCarIDs.length; i += 30) {
      carIDChunks.push(allCarIDs.slice(i, i + 30));
    }

    const [reviewsDocs, bookingsDocs] = await Promise.all([
      Promise.all(carIDChunks.map(chunk =>
        db.collection("reviews").where("carID", "in", chunk).get()
      )),
      Promise.all(carIDChunks.map(chunk =>
        db.collection("bookings").where("carID", "in", chunk).get()
      )),
    ]);

    const reviewCount  = {};
    const bookingCount = {};

    // Reviews from flagged customers don't count towards "most reviewed".
    const flaggedReviewers = await flaggedUserIDs(reviewsDocs.flat().flatMap(snap => snap.docs.map(doc => doc.data().userID)));
    reviewsDocs.flat().forEach(snap =>
      snap.docs.forEach(doc => {
        if (flaggedReviewers.has(String(doc.data().userID))) return;
        const cid = doc.data().carID;
        if (cid) reviewCount[cid] = (reviewCount[cid] || 0) + 1;
      })
    );
    bookingsDocs.flat().forEach(snap =>
      snap.docs.forEach(doc => {
        const cid = doc.data().carID;
        if (cid) bookingCount[cid] = (bookingCount[cid] || 0) + 1;
      })
    );

    const top3Reviewed = Object.entries(reviewCount)
      .sort((a, b) => b[1] - a[1]).slice(0, 3).map(([id]) => id);
    const top3Booked   = Object.entries(bookingCount)
      .sort((a, b) => b[1] - a[1]).slice(0, 3).map(([id]) => id);

    const featuredIDs = [...new Set([...top3Reviewed, ...top3Booked])];
    if (featuredIDs.length === 0) {
      return res.status(200).json({ mostReviewed: [], mostBooked: [] });
    }

    // 3. Resolve brand/model names
    const [brandDocs, modelDocs] = await Promise.all([
      Promise.all([...brandIDs].map((id) => db.collection("brand").doc(id).get())),
      Promise.all([...modelIDs].map((id) => db.collection("model").doc(id).get())),
    ]);

    const brandMap = {};
    brandDocs.forEach((d) => { if (d.exists) brandMap[d.id] = d.data().brandName || ""; });
    const modelMap = {};
    modelDocs.forEach((d) => { if (d.exists) modelMap[d.id] = d.data().modelName || ""; });

    // 4. Resolve full car details for featured cars only
    const resolvedMap = {};
    await Promise.all(
      featuredIDs.filter((id) => carDataMap[id]).map(async (id) => {
        resolvedMap[id] = await resolveCarDetails(id, carDataMap[id], brandMap, modelMap);
      })
    );

    const mostReviewed = top3Reviewed
      .filter((id) => resolvedMap[id])
      .map((id) => ({ ...resolvedMap[id], reviewCount: reviewCount[id] || 0 }));

    const mostBooked = top3Booked
      .filter((id) => resolvedMap[id])
      .map((id) => ({ ...resolvedMap[id], bookingCount: bookingCount[id] || 0 }));

    return res.status(200).json({ mostReviewed, mostBooked });

  } catch (error) {
    console.error("getFeaturedCars error:", error);
    return res.status(500).json({ message: "Failed to fetch featured cars." });
  }
};

// GET /api/cars/:carID/details — public: car info + booking COUNT + reviews (no booking list, no userIDs)
const getCarDetails = async (req, res) => {
  const { carID } = req.params;
  if (!carID) return res.status(400).json({ message: "carID is required." });

  try {
    // 1. Get car document
    const carDoc = await db.collection("cars").doc(carID).get();
    if (!carDoc.exists) return res.status(404).json({ message: "Car not found." });

    const carData = carDoc.data();
    if (isInactiveCar(carData)) return res.status(404).json({ message: "Car not found." });   // Inactive: same as a car that does not exist

    // 2. Fetch brand/model
    const [brandDoc, modelDoc] = await Promise.all([
      carData.brandID ? db.collection("brand").doc(carData.brandID).get() : Promise.resolve(null),
      carData.modelID ? db.collection("model").doc(carData.modelID).get() : Promise.resolve(null),
    ]);
    const brandMap = {};
    const modelMap = {};
    if (brandDoc?.exists) brandMap[carData.brandID] = brandDoc.data().brandName || "";
    if (modelDoc?.exists) modelMap[carData.modelID] = modelDoc.data().modelName || "";

    const carResolved = await resolveCarDetails(carID, carData, brandMap, modelMap);

    // 3. How many bookings this car has had. This endpoint is PUBLIC (no login), so it returns
    //    only the COUNT — it used to list every booking with its bookingID, userID, dates and
    //    status, which let anyone see who rented the car and when. (The booking calendar uses the
    //    separate, login-protected /api/services/car-bookings/:carID.)
    const bookingsSnap = await db.collection("bookings").where("carID", "==", carID).get();
    const bookingCount = bookingsSnap.size;

    // 4. Fetch all reviews for this car
    const reviewsSnap = await db.collection("reviews").where("carID", "==", carID).get();
    // Hide reviews written by a flagged customer (they stay visible to staff in the admin Reviews page).
    const flaggedReviewers = await flaggedUserIDs(reviewsSnap.docs.map((d) => d.data().userID));
    const reviews = reviewsSnap.docs.filter((doc) => !flaggedReviewers.has(String(doc.data().userID))).map((doc) => {
      const r = doc.data();
      // Public endpoint: never send the reviewer's real userID. A short one-way hash gives the
      // same reviewer the same label ("Customer 3fa9c1") without revealing who they are.
      const reviewer = r.userID ? crypto.createHash("sha256").update(String(r.userID)).digest("hex").slice(0, 6) : "";
      return {
        reviewID:  doc.id,
        userName:  reviewer ? `Customer ${reviewer}` : "Customer",
        rating:    r.rating    || 0,
        comment:   r.comment   || "",
        createdAt: r.createdAt || null,
      };
    });

    // Sort reviews by createdAt descending
    reviews.sort((a, b) => {
      const ta = a.createdAt?._seconds ? a.createdAt._seconds : 0;
      const tb = b.createdAt?._seconds ? b.createdAt._seconds : 0;
      return tb - ta;
    });

    return res.status(200).json({
      car:           carResolved,
      bookingCount,
      reviews,
      reviewCount:   reviews.length,
    });

  } catch (error) {
    console.error("getCarDetails error:", error);
    return res.status(500).json({ message: "Failed to fetch car details." });
  }
};

module.exports = { getAllCars, getFeaturedCars, getCarDetails };