const axios = require("axios");
const admin = require("firebase-admin");
const { db } = require("../../config/firebaseConnection/firebase");
const { computePaymentSplit } = require("../../utils/pricing");
const { recordAudit } = require("../../utils/auditLogs/auditLogs.util");
const { recordTransactionLog } = require("../../utils/transactionLogs/transactionLogs.util");
const { BOOKING_STATUS, enforceToPayValidity, promoteBookingToUpcoming, cancelStaleBooking, isFullyPaid } = require("../../utils/bookings/bookingStatus.util");
const { createNotification, resolveNotification } = require("../../services/notification/notification.service");

// ─── PayMongo base config ────────────────────────────────────────────────────
const PAYMONGO_SECRET = process.env.PAYMONGO_SECRET_KEY;
// Per PayMongo's current API reference (Create/Retrieve a Checkout Session),
// checkout_sessions live under v1, not v2 — this was previously wrong here
// and silently broke the status poll (see getPaymentStatus below).
const PAYMONGO_V1      = "https://api.paymongo.com/v1";

// Base URL of your frontend, e.g. https://arltrack.com — used to build success_url/cancel_url
const FRONTEND_URL = process.env.FRONTEND_URL || "http://localhost:3000";

const paymongoHeaders = () => ({
  "Content-Type":  "application/json",
  "Authorization": `Basic ${Buffer.from(PAYMONGO_SECRET + ":").toString("base64")}`,
});

// Maps our internal paymentMethod key -> PayMongo payment_method_types
const CHANNEL_MAP = {
  gcash: ["gcash"],
  maya:  ["paymaya"],
  qrph:  ["qrph"],
};

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/paymongo/create-link
//
// Creates a PayMongo Checkout Session for a booking (v2 API — supports
// success_url/cancel_url so the customer is redirected back to our app
// after paying, instead of staying on PayMongo's own success page).
// ─────────────────────────────────────────────────────────────────────────────
const createPaymentLink = async (req, res) => {
  const userID = req.user.userID;
  // NOTE: `amount` used to be trusted straight from the client (the browser
  // ran getPayNow() and sent the peso figure directly) — meaning anyone
  // could open devtools and check out for ₱20 instead of the real total.
  // It is intentionally no longer read from the request body: the charge
  // amount is now always derived below from the payment doc's own stored
  // grandTotal + methodOfPayment.
  const { bookingID, paymentID, description, paymentMethod } = req.body;

  if (!bookingID || !paymentID) {
    return res.status(400).json({ message: "bookingID and paymentID are required." });
  }

  const paymentMethodTypes = CHANNEL_MAP[paymentMethod] || ["qrph"];

  try {
    // 1. Verify the payment doc belongs to this user
    const paymentSnap = await db.collection("payments")
      .where("paymentID", "==", paymentID)
      .where("userID", "==", userID)
      .limit(1)
      .get();

    if (paymentSnap.empty) {
      return res.status(404).json({ message: "Payment record not found or access denied." });
    }

    const paymentDoc = paymentSnap.docs[0];
    const payment    = paymentDoc.data();

    // ── Only allow starting payment/confirmation if the booking's own
    // schedule is still valid (hasn't passed its 12h "to pay" window, and
    // its start date/time hasn't already gone by). This is enforced HERE
    // rather than after the fact — once PayMongo has actually charged the
    // customer there's no clean way to "un-charge" them, so the gate has
    // to sit in front of checkout, not behind it. If it's gone stale, this
    // cancels it in the same step (self-heal — see enforceToPayValidity)
    // instead of leaving it dangling as "to pay" for the next cron sweep.
    const bookingSnap = await db.collection("bookings").where("bookingID", "==", bookingID).limit(1).get();
    if (bookingSnap.empty) {
      return res.status(404).json({ message: "Booking not found." });
    }
    const booking = bookingSnap.docs[0].data();

    if (booking.status === BOOKING_STATUS.TO_PAY) {
      const stillValidStatus = await enforceToPayValidity(bookingID, booking);
      if (stillValidStatus !== BOOKING_STATUS.TO_PAY) {
        return res.status(400).json({
          message: "This booking's schedule is no longer valid and it has been cancelled. Please make a new booking.",
        });
      }
    } else if (booking.status !== BOOKING_STATUS.UPCOMING) {
      // Not "to pay" and not already "upcoming" (e.g. cancelled/completed) —
      // there's nothing left here to pay for.
      return res.status(400).json({ message: "This booking can no longer be paid for." });
    }

    // Server-computed charge amount — the only amount PayMongo ever sees.
    //
    // Two-phase payment: "deposit" (the default — payNow, 50% for Partial /
    // 100% for Full) and, for Partial only, "balance" (the remaining 50%,
    // only payable once the deposit has actually cleared). phase comes from
    // the request body and defaults to "deposit" so any existing caller
    // that doesn't send it keeps behaving exactly as before.
    const phase      = req.body.phase === "balance" ? "balance" : "deposit";
    const isPartial  = String(payment.methodOfPayment).toLowerCase() === "partial";

    let amountToCharge;
    if (phase === "balance") {
      if (!isPartial) {
        return res.status(400).json({ message: "This booking doesn't have a separate balance payment." });
      }
      if (payment.status !== "paid") {
        return res.status(400).json({ message: "Please complete the deposit payment first." });
      }
      if (payment.balanceStatus === "paid") {
        return res.status(400).json({ message: "The balance has already been paid." });
      }
      amountToCharge = Number(payment.balanceAmount) || 0;
    } else {
      const { payNow } = computePaymentSplit(payment.amount, payment.methodOfPayment);
      amountToCharge = payNow;
    }

    const amountInCentavos = Math.round(amountToCharge * 100);
    if (isNaN(amountInCentavos) || amountInCentavos < 2000) {
      return res.status(400).json({ message: "Amount must be at least ₱20.00." });
    }

    // Prevent duplicate sessions for the SAME phase if one already exists
    // and is still pending. Checked against that phase's own status field
    // (not just the generic `status`) — a deposit session lingering as
    // "pending" shouldn't block starting the separate balance session
    // later, and vice versa.
    const phaseStatus = phase === "balance" ? payment.balanceStatus : payment.status;
    if (payment.paymongoSessionID && payment.currentPhase === phase && phaseStatus === "pending") {
      return res.status(200).json({
        message:     "Payment link already exists.",
        checkoutUrl: payment.checkoutUrl,
        linkID:      payment.paymongoSessionID,
      });
    }

    // 2. Build return URLs — success_url carries paymentID so the frontend
    //    can immediately poll /paymongo/status/:paymentID on return.
    const successUrl = `${FRONTEND_URL}/payment-return?paymentID=${paymentID}&bookingID=${bookingID}`;
    const cancelUrl   = `${FRONTEND_URL}/booking?step=4&paymentID=${paymentID}`;

    // 3. Create PayMongo Checkout Session (v2)
    const sessionPayload = {
      data: {
        attributes: {
          line_items: [
            {
              name:     description || `ARLTrack Booking #${bookingID}${phase === "balance" ? " (Balance)" : ""}`,
              amount:   amountInCentavos,
              currency: "PHP",
              quantity: 1,
            },
          ],
          payment_method_types: paymentMethodTypes,
          success_url:          successUrl,
          cancel_url:           cancelUrl,
          reference_number:     paymentID, // easiest way to match it back in the webhook
        },
      },
    };

    const pmRes = await axios.post(
      `${PAYMONGO_V1}/checkout_sessions`,
      sessionPayload,
      { headers: paymongoHeaders() }
    );

    const sessionData = pmRes.data.data;
    const sessionID    = sessionData.id;
    const checkoutUrl  = sessionData.attributes.checkout_url;

    // 4. Save sessionID + checkoutUrl to Firestore
    await paymentDoc.ref.update({
      paymongoSessionID: sessionID,
      paymongoChannel:   paymentMethodTypes[0],
      checkoutUrl,
      currentPhase:      phase,
      ...(phase === "balance" ? { balanceStatus: "pending" } : {}),
      updatedAt: new Date(),
    });

    return res.status(200).json({
      message: "Payment link created.",
      checkoutUrl,
      linkID: sessionID,
    });

  } catch (error) {
    console.error("createPaymentLink error:", error?.response?.data || error.message);
    return res.status(500).json({ message: "Failed to create payment link. Please try again." });
  }
};

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/paymongo/webhook
//
// Subscribe to `checkout_session.payment.paid` in your PayMongo dashboard
// (Settings → Webhooks) — this replaces the old `payment.paid` event since
// we moved from Links to Checkout Sessions.
// ─────────────────────────────────────────────────────────────────────────────
const handleWebhook = async (req, res) => {
  const webhookSecret = process.env.PAYMONGO_WEBHOOK_SECRET;

  const sigHeader = req.headers["paymongo-signature"];

  // Whenever a webhook secret IS configured, a signature header is
  // mandatory — not optional. The old check here was
  // `if (webhookSecret && sigHeader)`, which only ran verification when
  // BOTH were present. That meant anyone could skip verification
  // entirely just by leaving the Paymongo-Signature header off their
  // request — this endpoint has no auth middleware (PayMongo calls it
  // directly), so a forged POST with a real paymentID could mark any
  // pending payment "paid" for free. Failing closed here (reject when
  // secret is set but header is missing) closes that gap.
  if (webhookSecret && !sigHeader) {
    console.warn("PayMongo webhook: missing signature header while a webhook secret is configured — rejecting.");
    return res.status(400).json({ message: "Missing signature." });
  }

  if (webhookSecret && sigHeader) {
    const crypto = require("crypto");
    const parts  = {};
    sigHeader.split(",").forEach(part => {
      const [k, v] = part.split("=");
      parts[k] = v;
    });

    // Must sign the EXACT bytes PayMongo sent — re-stringifying the parsed
    // req.body can produce different key order/spacing and will silently
    // never match. req.rawBody is captured by the express.json({ verify })
    // hook in index.js; fall back to JSON.stringify only if that's missing.
    const rawBody = req.rawBody ? req.rawBody.toString("utf8") : JSON.stringify(req.body);
    const toSign  = `${parts.t}.${rawBody}`;
    const hmac    = crypto.createHmac("sha256", webhookSecret).update(toSign).digest("hex");

    // Constant-time comparison — a plain `===` bails out at the first
    // differing character, so how long the check takes leaks how many
    // leading hex characters an attacker's guess got right. That's a
    // narrow, largely theoretical attack over a network (a lot of
    // requests needed per character), but timingSafeEqual closes it for
    // free. It throws on mismatched buffer lengths instead of returning
    // false, so length is checked first — a missing/malformed `te`/`li`
    // segment just fails the comparison instead of crashing the request.
    const safeEqual = (a, b) => {
      if (typeof a !== "string" || typeof b !== "string") return false;
      const bufA = Buffer.from(a, "utf8");
      const bufB = Buffer.from(b, "utf8");
      if (bufA.length !== bufB.length) return false;
      return crypto.timingSafeEqual(bufA, bufB);
    };
    const isValid = safeEqual(hmac, parts.te) || safeEqual(hmac, parts.li);

    if (!isValid) {
      console.warn("PayMongo webhook: invalid signature");
      return res.status(400).json({ message: "Invalid signature." });
    }
  }

  const event     = req.body;
  const eventType = event?.data?.attributes?.type;
  const session    = event?.data?.attributes?.data; // checkout_session object

  console.log("[PayMongo Webhook] event type:", eventType);

  if (!eventType || !session) {
    return res.status(200).json({ received: true });
  }

  try {
    // We set reference_number = paymentID when creating the session
    const paymentID = session?.attributes?.reference_number;
    const sessionID = session?.id;

    if (eventType === "checkout_session.payment.paid") {
      const now = new Date();

      let paymentSnap;
      if (paymentID) {
        paymentSnap = await db.collection("payments")
          .where("paymentID", "==", paymentID)
          .limit(1)
          .get();
      } else if (sessionID) {
        paymentSnap = await db.collection("payments")
          .where("paymongoSessionID", "==", sessionID)
          .limit(1)
          .get();
      }

      if (!paymentSnap || paymentSnap.empty) {
        console.warn("[PayMongo Webhook] no matching payment found. sessionID:", sessionID, "paymentID:", paymentID);
        return res.status(200).json({ received: true });
      }

      const paymentDoc = paymentSnap.docs[0];
      const payment    = paymentDoc.data();
      const bID        = payment.bookingID;
      const phase      = payment.currentPhase === "balance" ? "balance" : "deposit";

      // getPaymentStatus (the poll a customer's browser hits when it's
      // redirected back from PayMongo's checkout page) can win the race
      // and already mark THIS SAME PHASE "paid" before the webhook arrives.
      // Checked against the phase's own status field, not just the generic
      // `status` — a Partial booking's deposit stays "paid" forever, which
      // used to make this wrongly treat the balance phase's own later
      // webhook event as a duplicate and skip it entirely.
      const alreadyPaid = phase === "balance" ? payment.balanceStatus === "paid" : payment.status === "paid";
      if (alreadyPaid) {
        console.log(`[PayMongo Webhook] ${phase} payment already marked paid (handled via status poll) — skipping duplicate log for:`, bID);
        return res.status(200).json({ received: true });
      }

      // The checkout_session payload embeds the underlying PayMongo payment
      // object(s) under attributes.payments — that payment's own `id` is
      // what the Refunds API needs (POST /v1/refunds requires payment_id,
      // NOT the checkout_session id). We grab and store it here so refunds
      // are possible later without an extra lookup.
      const paidPayments   = session?.attributes?.payments || [];
      const paymongoPaymentID = paidPayments[0]?.id || null;

      const updatePayload = phase === "balance"
        ? { balanceStatus: "paid", balancePaidAt: now, updatedAt: now }
        : { status: "paid", paidAt: now, updatedAt: now };
      if (paymongoPaymentID) {
        updatePayload.paymongoPaymentID = paymongoPaymentID; // most recent charge's PayMongo payment ID
      } else {
        console.warn("[PayMongo Webhook] payment.paid event had no payments[0].id — refunds for this payment will need a manual lookup.");
      }

      await paymentDoc.ref.update(updatePayload);

      // Booking only moves to "upcoming" once FULLY paid — for a Partial
      // booking that means BOTH this and the deposit phase; for a Full
      // booking (single phase) this alone is enough. promoteBookingToUpcoming
      // checks that itself (isFullyPaid, bookingStatus.util.js), so a
      // Partial deposit-only payment correctly leaves the booking on "to pay".
      if (bID) {
        await promoteBookingToUpcoming(bID);
        console.log(`[PayMongo Webhook] ✅ ${phase} payment settled for booking:`, bID, "paymongoPaymentID:", paymongoPaymentID);
      }

      recordAudit({
        action: "update",
        description: `Payment ${paymentID || sessionID} — ${phase} settled (paid)${bID ? ` for booking ${bID}` : ""}.`,
        userID: payment.userID || null,
      });

      recordTransactionLog({
        bookingID: bID,
        paymentID: payment.paymentID || paymentID,
        userID: payment.userID || null,
        type: "Payment",
        // The amount actually charged for THIS phase — not the full grand
        // total (payment.amount), which used to be logged here even for a
        // Partial deposit that only charged 50%. That would double-count
        // once the balance phase's own charge is logged separately too.
        amount: phase === "balance"
          ? (Number(payment.balanceAmount) || 0)
          : (computePaymentSplit(payment.amount, payment.methodOfPayment).payNow || 0),
        status: "Success",
        paymentMethod: payment.paymentMethod || "—",
        referenceNumber: payment.referenceNumber || "—",
        description: `${phase === "balance" ? "Balance" : "Deposit"} payment settled via PayMongo${bID ? ` for booking ${bID}` : ""}.`,
      });

      // ── Notify the customer: this phase's payment cleared ──
      // "Booking Confirmed" only fires once the booking is FULLY paid
      // (isFullyPaid) — a Partial booking's deposit clearing gets just the
      // "Payment Successful" card; the confirmation card waits for the
      // balance phase too, same gate promoteBookingToUpcoming itself uses.
      if (payment.userID) {
        try {
          const chargedAmount = phase === "balance"
            ? (Number(payment.balanceAmount) || 0)
            : (computePaymentSplit(payment.amount, payment.methodOfPayment).payNow || 0);

          await createNotification({
            type: "payment_successful",
            userID: payment.userID,
            refID: bID,
            title: "Payment Successful",
            message: `Your ${phase === "balance" ? "balance" : "deposit"} payment of ₱${chargedAmount.toLocaleString()} was received.`,
          });

          if (isFullyPaid({ ...payment, ...updatePayload })) {
            await createNotification({
              type: "booking_confirmed",
              userID: payment.userID,
              refID: bID,
              title: "Booking Confirmed",
              message: "Your booking has been confirmed. We look forward to serving you!",
            });
          }

          await resolveNotification("payment_pending", bID, payment.userID);
        } catch (notifErr) {
          console.error("[PayMongo Webhook] failed to write customer notifications:", notifErr.message);
        }
      }

      return res.status(200).json({ received: true });
    }

    // ACK all other event types (e.g. checkout_session.payment.failed, if you enable it)
    if (eventType === "checkout_session.payment.failed") {
      const now = new Date();
      let paymentSnap;
      if (paymentID) {
        paymentSnap = await db.collection("payments")
          .where("paymentID", "==", paymentID)
          .limit(1)
          .get();
      } else if (sessionID) {
        paymentSnap = await db.collection("payments")
          .where("paymongoSessionID", "==", sessionID)
          .limit(1)
          .get();
      }
      if (paymentSnap && !paymentSnap.empty) {
        const failedPayment = paymentSnap.docs[0].data();
        const phase = failedPayment.currentPhase === "balance" ? "balance" : "deposit";

        if (phase === "balance") {
          // Balance failed — the deposit is already real money collected,
          // so this does NOT cancel the booking (that would need a refund,
          // which this auto-cancel path doesn't handle). Just mark the
          // balance failed so the customer can retry paying it; the
          // booking stays "to pay" either way.
          await paymentSnap.docs[0].ref.update({ balanceStatus: "failed", updatedAt: now });

          if (failedPayment.userID) {
            await createNotification({
              type: "payment_failed",
              userID: failedPayment.userID,
              refID: failedPayment.bookingID || null,
              title: "Payment Failed",
              message: "Your balance payment could not be processed. Please try again to complete your booking.",
            }).catch((e) => console.error("[PayMongo Webhook] failed to write payment_failed notification:", e.message));
          }
        } else {
          // Deposit failed (including choosing PayMongo's test-mode "Fail"
          // option) — nothing has actually been charged yet, so it's safe
          // to cancel the booking outright instead of leaving it dangling
          // as "to pay". It shouldn't count as a real booking just because
          // someone started, then failed, a checkout. To try again, the
          // customer books fresh.
          await paymentSnap.docs[0].ref.update({ status: "failed", updatedAt: now });
          if (failedPayment.bookingID) {
            await cancelStaleBooking(failedPayment.bookingID, "Booking cancelled: payment failed.");
          }

          // cancelStaleBooking() above already sends the "Booking Cancelled"
          // notification (single choke-point — see its own header comment) —
          // this just adds the payment-specific "Payment Failed" card on top.
          if (failedPayment.userID) {
            await createNotification({
              type: "payment_failed",
              userID: failedPayment.userID,
              refID: failedPayment.bookingID || null,
              title: "Payment Failed",
              message: "Your payment could not be processed, so this booking was not confirmed. Please book again to try once more.",
            }).catch((e) => console.error("[PayMongo Webhook] failed to write payment_failed notification:", e.message));
          }
        }
      }
      return res.status(200).json({ received: true });
    }

    // ─────────────────────────────────────────────────────────────────────
    // payment.refund.updated — PayMongo confirming a refund we created (via the
    // Refunds API from the admin backend after an admin approves a
    // RefundRequest) has settled, one way or another.
    // NOTE: the actual event name PayMongo sends is "payment.refund.updated"
    // (per their webhook docs — "refund.updated" on its own does not exist
    // and will never match, silently leaving requests stuck on "Approved").
    // The refund object's own `payment_id` field is what we'd match on,
    // but we actually match by the refund's own `id` since that's what
    // the admin backend stores on the RefundRequest right after creating
    // it — NOT paymentID/sessionID like the events above, since this
    // event isn't about the checkout_session at all.
    // ─────────────────────────────────────────────────────────────────────
    if (eventType === "payment.refund.updated") {
      const refund       = event?.data?.attributes?.data; // refund object
      const refundStatus = refund?.attributes?.status;    // pending | succeeded | failed
      const refundID     = refund?.id;
      const now = new Date();

      if (!refundID || !refundStatus) {
        console.warn("[PayMongo Webhook] payment.refund.updated missing refund id/status.");
        return res.status(200).json({ received: true });
      }

      // Only act on terminal states — "pending" just means still processing.
      if (refundStatus !== "succeeded" && refundStatus !== "failed") {
        return res.status(200).json({ received: true });
      }

      const refundReqSnap = await db.collection("refundRequests")
        .where("paymongoRefundID", "==", refundID)
        .limit(1)
        .get();

      if (refundReqSnap.empty) {
        console.warn("[PayMongo Webhook] payment.refund.updated — no matching refundRequest for refundID:", refundID);
        return res.status(200).json({ received: true });
      }

      const refundReqDoc = refundReqSnap.docs[0];
      const refundReq    = refundReqDoc.data();

      if (refundStatus === "succeeded") {
        await refundReqDoc.ref.update({ status: "Refunded", updatedAt: now });

        // Also flip the underlying payment to Refunded so admin Payments
        // pages reflect it without a separate manual step.
        if (refundReq.paymentID) {
          const paymentSnap = await db.collection("payments")
            .where("paymentID", "==", refundReq.paymentID)
            .limit(1)
            .get();
          if (!paymentSnap.empty) {
            await paymentSnap.docs[0].ref.update({ status: "Refunded", updatedAt: now });
          }
        }
        console.log("[PayMongo Webhook] ✅ Refund succeeded for refundRequest:", refundReq.refundRequestID);
        recordAudit({
          action: "update",
          description: `Refund ${refundReq.refundRequestID} succeeded for payment ${refundReq.paymentID}.`,
          userID: refundReq.userID || null,
        });
        recordTransactionLog({
          bookingID: refundReq.bookingID,
          paymentID: refundReq.paymentID,
          refundRequestID: refundReq.refundRequestID,
          userID: refundReq.userID || null,
          type: "Refund",
          amount: refundReq.amount || 0,
          status: "Refunded",
          description: `Refund confirmed by PayMongo for payment ${refundReq.paymentID}.`,
        });

        if (refundReq.userID) {
          await createNotification({
            type: "refund_completed",
            userID: refundReq.userID,
            refID: refundReq.bookingID || null,
            title: "Refund Completed",
            message: `Your refund of ₱${Number(refundReq.amount || 0).toLocaleString()} has been sent back to your original payment method.`,
          }).catch((e) => console.error("[PayMongo Webhook] failed to write refund_completed notification:", e.message));
        }
      } else {
        await refundReqDoc.ref.update({ status: "Failed", updatedAt: now });
        console.log("[PayMongo Webhook] ❌ Refund failed for refundRequest:", refundReq.refundRequestID);
        recordAudit({
          action: "update",
          description: `Refund ${refundReq.refundRequestID} failed for payment ${refundReq.paymentID}.`,
          userID: refundReq.userID || null,
        });
        recordTransactionLog({
          bookingID: refundReq.bookingID,
          paymentID: refundReq.paymentID,
          refundRequestID: refundReq.refundRequestID,
          userID: refundReq.userID || null,
          type: "Refund",
          amount: refundReq.amount || 0,
          status: "Failed",
          description: `PayMongo reported this refund as failed for payment ${refundReq.paymentID}.`,
        });

        if (refundReq.userID) {
          await createNotification({
            type: "refund_failed",
            userID: refundReq.userID,
            refID: refundReq.bookingID || null,
            title: "Refund Failed",
            message: `Your approved refund of ₱${Number(refundReq.amount || 0).toLocaleString()} could not be completed by PayMongo. Please contact support.`,
          }).catch((e) => console.error("[PayMongo Webhook] failed to write refund_failed notification:", e.message));
        }
      }

      return res.status(200).json({ received: true });
    }

    return res.status(200).json({ received: true });

  } catch (error) {
    console.error("handleWebhook error:", error.message);
    return res.status(200).json({ received: true });
  }
};

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/paymongo/status/:paymentID
// ─────────────────────────────────────────────────────────────────────────────
const getPaymentStatus = async (req, res) => {
  const userID    = req.user.userID;
  const { paymentID } = req.params;

  if (!paymentID) {
    return res.status(400).json({ message: "paymentID is required." });
  }

  try {
    const snap = await db.collection("payments")
      .where("paymentID", "==", paymentID)
      .where("userID", "==", userID)
      .limit(1)
      .get();

    if (snap.empty) {
      return res.status(404).json({ message: "Payment not found." });
    }

    const p = snap.docs[0].data();
    const phase       = p.currentPhase === "balance" ? "balance" : "deposit";
    const phaseStatus = phase === "balance" ? p.balanceStatus : p.status;

    // Poll based on the CURRENT phase's own status — not just the generic
    // `status`, which stays "paid" forever once the deposit clears. Without
    // this, a Partial booking's balance checkout would never actually get
    // polled here: p.status === "paid" (from the deposit) would make this
    // condition false, and the customer's browser would just sit showing
    // the last-known Firestore status instead of ever checking PayMongo.
    if (phaseStatus === "pending" && p.paymongoSessionID) {
      try {
        const pmRes = await axios.get(
          `${PAYMONGO_V1}/checkout_sessions/${p.paymongoSessionID}`,
          { headers: paymongoHeaders() }
        );
        const payments = pmRes.data?.data?.attributes?.payments || [];
        const paidPayment = payments.find(pay => pay.attributes?.status === "paid");

        if (paidPayment && phaseStatus !== "paid") {
          const now = new Date();
          const updatePayload = phase === "balance"
            ? { balanceStatus: "paid", balancePaidAt: now, updatedAt: now, paymongoPaymentID: paidPayment.id }
            : { status: "paid", paidAt: now, updatedAt: now, paymongoPaymentID: paidPayment.id };
          await snap.docs[0].ref.update(updatePayload);

          // Same promotion the webhook does — this poll can win the race
          // against the webhook, so it has to do this itself too rather
          // than assuming the webhook already will have. Only actually
          // flips the booking to "upcoming" once FULLY paid (see
          // isFullyPaid) — a Partial deposit confirmed here still leaves
          // the booking on "to pay" until the balance phase also clears.
          if (p.bookingID) {
            await promoteBookingToUpcoming(p.bookingID);
          }

          // This poll can win the race against the webhook — the browser
          // redirect back from PayMongo's checkout page often arrives
          // before PayMongo's own webhook delivery does. Since this is the
          // only other place a payment gets flipped to "paid", it has to
          // log the transaction itself too, or a payment settled this way
          // never appears in Transaction Logs at all (the webhook handler
          // is the only other place that calls recordTransactionLog, and
          // it has no way of knowing this already happened).
          recordAudit({
            action: "update",
            description: `Payment ${paymentID} — ${phase} settled (paid)${p.bookingID ? ` for booking ${p.bookingID}` : ""} — confirmed via status poll.`,
            userID: p.userID || null,
          });

          recordTransactionLog({
            bookingID: p.bookingID,
            paymentID: p.paymentID || paymentID,
            userID: p.userID || null,
            type: "Payment",
            amount: phase === "balance"
              ? (Number(p.balanceAmount) || 0)
              : (computePaymentSplit(p.amount, p.methodOfPayment).payNow || 0),
            status: "Success",
            description: `${phase === "balance" ? "Balance" : "Deposit"} payment confirmed via status poll (checkout_session ${p.paymongoSessionID}).`,
          });

          // Same pair of cards as the webhook path — createNotification()'s
          // dedup means whichever of the two (webhook vs. this poll) lands
          // first "wins" and the other is a no-op, so there's never a
          // duplicate even though both paths can reach here for the same payment.
          if (p.userID) {
            try {
              const chargedAmount = phase === "balance"
                ? (Number(p.balanceAmount) || 0)
                : (computePaymentSplit(p.amount, p.methodOfPayment).payNow || 0);

              await createNotification({
                type: "payment_successful",
                userID: p.userID,
                refID: p.bookingID,
                title: "Payment Successful",
                message: `Your ${phase === "balance" ? "balance" : "deposit"} payment of ₱${chargedAmount.toLocaleString()} was received.`,
              });

              if (isFullyPaid({ ...p, ...updatePayload })) {
                await createNotification({
                  type: "booking_confirmed",
                  userID: p.userID,
                  refID: p.bookingID,
                  title: "Booking Confirmed",
                  message: "Your booking has been confirmed. We look forward to serving you!",
                });
              }

              await resolveNotification("payment_pending", p.bookingID, p.userID);
            } catch (notifErr) {
              console.error("getPaymentStatus: failed to write customer notifications:", notifErr.message);
            }
          }

          return res.status(200).json({ status: "paid", bookingID: p.bookingID, phase });
        }
        return res.status(200).json({ status: phaseStatus, bookingID: p.bookingID, phase });
      } catch (e) {
        // Previously swallowed silently, which is exactly why a real failure
        // here (e.g. the v1/v2 endpoint mismatch this fixes) went unnoticed
        // and just looked like "payment stuck pending" forever. Log it so a
        // future failure here is actually visible, then fall through to the
        // last-known Firestore status rather than erroring the request.
        console.error(
          "getPaymentStatus: PayMongo checkout_sessions lookup failed —",
          e?.response?.status, e?.response?.data || e.message
        );
      }
    }

    return res.status(200).json({
      status:      phaseStatus,
      bookingID:   p.bookingID,
      checkoutUrl: p.checkoutUrl || null,
      phase,
    });

  } catch (error) {
    console.error("getPaymentStatus error:", error.message);
    return res.status(500).json({ message: "Failed to fetch payment status." });
  }
};

const VALID_REFUND_REASONS = [
  "Cancelled trip",
  "Overcharged",
  "Service issue",
  "Duplicate payment",
  "Other",
];

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/paymongo/refunds
// Customer submits a refund request for one of their own paid payments —
// the "Confirm & Send" step. This only writes a Pending refundRequests doc;
// it never calls PayMongo directly. That only happens once an admin
// approves it from the admin backend.
// ─────────────────────────────────────────────────────────────────────────────
// Mirrors getPaymentInfo() in MyBookings.jsx (customer) and computeAmounts()
// in payments.service.js (admin) — so refunds are capped at what was
// ACTUALLY paid (e.g. a 50% down payment), not the full booking total.
// PayMongo will reject a refund amount greater than what it actually
// received on that payment_id.
const computeAmountPaid = (payment) => {
  const amount     = Number(payment.amount) || 0;
  const depositFee = Number(payment.depositFee) || 0;
  const method     = (payment.methodOfPayment || "").toLowerCase();
  const status     = (payment.status || "").toLowerCase();

  if (method.includes("full")) return amount;
  // "Partial" is what computePaymentSplit() actually produces, and it charges
  // 50% of the grand total via PayMongo (payNow = Math.floor(total * 0.5)).
  // MUST use the same Math.floor here — Math.round would disagree with
  // computePaymentSplit() by ₱1 whenever the grand total is an odd number
  // of pesos (e.g. ₱2,503 → floor=₱1,251 actually charged, but
  // round=₱1,252), causing PayMongo to reject the refund for exceeding
  // what it actually received on that payment_id.
  if (method.includes("partial") || method.includes("down")) return Math.floor(amount / 2);
  if (method.includes("deposit")) return depositFee; // true deposit-only flow, if ever used
  if (status === "paid" || status === "approved") return amount;
  return depositFee;
};

const requestRefund = async (req, res) => {
  const userID = req.user.userID;
  const { paymentID, reason, notes } = req.body;

  if (!paymentID || !reason) {
    return res.status(400).json({ message: "paymentID and reason are required." });
  }
  if (!VALID_REFUND_REASONS.includes(reason)) {
    return res.status(400).json({ message: "Invalid reason." });
  }

  try {
    const paymentSnap = await db.collection("payments")
      .where("paymentID", "==", paymentID)
      .where("userID", "==", userID)
      .limit(1)
      .get();

    if (paymentSnap.empty) {
      return res.status(404).json({ message: "Payment not found or access denied." });
    }

    const paymentDoc = paymentSnap.docs[0];
    const payment    = paymentDoc.data();

    if (payment.status !== "paid") {
      return res.status(400).json({ message: "Only paid payments can be refunded." });
    }
    if (!payment.paymongoPaymentID) {
      // Settled before the webhook fix that captures the real PayMongo
      // payment id — flag it instead of creating a request that can
      // never actually be refunded via PayMongo.
      return res.status(400).json({
        message: "This payment can't be auto-refunded yet — please contact support.",
      });
    }

    const existingSnap = await db.collection("refundRequests")
      .where("paymentID", "==", paymentID)
      .where("status", "in", ["Pending", "Approved"])
      .limit(1)
      .get();

    if (!existingSnap.empty) {
      return res.status(409).json({ message: "A refund request for this payment is already in progress." });
    }

    const refundRef = db.collection("refundRequests").doc();
    const now = new Date();
    const amountPaid = computeAmountPaid(payment);
    const refundRequest = {
      refundRequestID: refundRef.id,
      bookingID: payment.bookingID || null,
      paymentID,
      userID,
      reason,
      notes: notes || "",
      amount: amountPaid, // ← what was actually paid, not the full booking total
      status: "Pending",
      paymongoRefundID: null,
      processedBy: null,
      processedAt: null,
      rejectReason: null,
      createdAt: now,
      updatedAt: now,
    };

    await refundRef.set(refundRequest);

    recordAudit({
      action: "create",
      description: `Refund requested by customer for payment ${paymentID} (reason: ${reason}).`,
      userID,
    });

    // Written directly here rather than relying on the admin backend to
    // notice this via a Firestore watcher — the admin backend runs as a
    // Vercel serverless function (app.listen + @vercel/node), which does
    // NOT keep a persistent process alive to run onSnapshot() listeners
    // reliably between requests. Writing the notification synchronously,
    // in the same request that creates the refund request, has no such
    // dependency — it either succeeds here or it doesn't, same as any
    // other write in this function. Matches the exact document shape
    // admin-backend/services/notification/notification.service.js
    // creates, so the existing bell UI needs no changes to read it.
    db.collection("notifications").add({
      type: "refund_request",
      refID: refundRef.id,
      refCollection: "refundRequests",
      title: "Refund Request",
      message: `A refund request for ₱${Number(amountPaid).toLocaleString()} is awaiting review.`,
      isRead: false,
      status: "active",
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      resolvedAt: null,
    }).catch((err) => console.error("[requestRefund] Failed to write notification:", err.message));

    return res.status(201).json({
      message: "Refund request sent. We'll notify you once it's reviewed.",
      refundRequest,
    });
  } catch (error) {
    console.error("requestRefund error:", error.message);
    return res.status(500).json({ message: "Failed to submit refund request." });
  }
};

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/paymongo/refunds/mine
// Lists the logged-in customer's own refund requests (newest first).
// ─────────────────────────────────────────────────────────────────────────────
const getMyRefundRequests = async (req, res) => {
  const userID = req.user.userID;

  try {
    const snap = await db.collection("refundRequests")
      .where("userID", "==", userID)
      .get();

    const requests = snap.docs
      .map(d => d.data())
      .sort((a, b) => {
        const aT = a.createdAt?.toDate ? a.createdAt.toDate() : new Date(a.createdAt);
        const bT = b.createdAt?.toDate ? b.createdAt.toDate() : new Date(b.createdAt);
        return bT - aT;
      });

    return res.status(200).json({ data: requests });
  } catch (error) {
    console.error("getMyRefundRequests error:", error.message);
    return res.status(500).json({ message: "Failed to fetch refund requests." });
  }
};

module.exports = { createPaymentLink, handleWebhook, getPaymentStatus, requestRefund, getMyRefundRequests };
